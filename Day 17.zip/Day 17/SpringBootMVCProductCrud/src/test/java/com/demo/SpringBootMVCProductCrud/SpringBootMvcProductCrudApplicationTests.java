package com.demo.SpringBootMVCProductCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMvcProductCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
