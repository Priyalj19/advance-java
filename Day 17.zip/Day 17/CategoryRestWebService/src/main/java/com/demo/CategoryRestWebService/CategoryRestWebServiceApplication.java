package com.demo.CategoryRestWebService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CategoryRestWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CategoryRestWebServiceApplication.class, args);
	}

}
