package com.demo.CategoryRestWebService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoryRestWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
